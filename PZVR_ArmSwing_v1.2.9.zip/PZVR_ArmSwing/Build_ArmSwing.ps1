$ErrorActionPreference = "Stop"
$modRoot = [System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Path)

try {
  Write-Host "Compiler | Mod folder: $modRoot" -ForegroundColor Cyan

  function Dir-Exists([string]$p) {
    if ([string]::IsNullOrWhiteSpace($p)) { return $false }
    try { return [System.IO.Directory]::Exists($p) } catch { return $false }
  }
  function File-Exists([string]$p) {
    if ([string]::IsNullOrWhiteSpace($p)) { return $false }
    try { return [System.IO.File]::Exists($p) } catch { return $false }
  }
  function Join-WinPath([string]$a, [string]$b) {
    if ([string]::IsNullOrWhiteSpace($a)) { return $b }
    if ([string]::IsNullOrWhiteSpace($b)) { return $a }
    return [System.IO.Path]::Combine($a, $b)
  }
  function Ensure-Dir([string]$p) {
    if (-not (Dir-Exists $p)) {
      [System.IO.Directory]::CreateDirectory($p) | Out-Null
    }
  }
  function Clean-Dir([string]$p) {
    if (Dir-Exists $p) {
      [System.IO.Directory]::Delete($p, $true)
    }
    [System.IO.Directory]::CreateDirectory($p) | Out-Null
  }

  # 1. Locate JDK 25+ javac.exe & jar.exe (PZ Build 42.22.2 classes are Java 25 / v69.0)
  function Get-JavacMajor([string]$javacPath) {
    if (-not (File-Exists $javacPath)) { return 0 }
    $oldPref = $ErrorActionPreference
    try {
      $ErrorActionPreference = "Continue"
      $verOut = (& $javacPath -version 2>&1) | Out-String
      if ($verOut -match 'javac\s+(\d+)') {
        return [int]$Matches[1]
      }
    } catch {} finally {
      $ErrorActionPreference = $oldPref
    }
    return 0
  }

  function Find-Jdk25Pair {
    $candidates = @()
    $cmd = Get-Command "javac.exe" -ErrorAction SilentlyContinue
    if ($cmd) { $candidates += $cmd.Source }
    $portable25 = Join-WinPath $env:LOCALAPPDATA "PZVR_ArmSwing\jdk25"
    if (Dir-Exists $portable25) {
      $candidates += [System.IO.Directory]::GetFiles($portable25, "javac.exe", [System.IO.SearchOption]::AllDirectories)
    }
    foreach ($root in @("C:\Program Files\Java","C:\Program Files\Eclipse Adoptium","C:\Program Files\Microsoft","C:\Program Files\Zulu","C:\Program Files\Amazon Corretto")) {
      if (Dir-Exists $root) {
        $candidates += [System.IO.Directory]::GetFiles($root, "javac.exe", [System.IO.SearchOption]::AllDirectories)
      }
    }
    foreach ($c in ($candidates | Select-Object -Unique)) {
      $maj = Get-JavacMajor $c
      if ($maj -ge 25) {
        $jarSibling = Join-WinPath ([System.IO.Path]::GetDirectoryName($c)) "jar.exe"
        if (File-Exists $jarSibling) {
          return @{ Javac = $c; Jar = $jarSibling; Major = $maj }
        }
      }
    }
    return $null
  }

  $jdkPair = Find-Jdk25Pair

  if (-not $jdkPair) {
    Write-Host "PZ Build 42.22.2 requires Java 25 (class v69.0). Downloading portable Eclipse Temurin JDK 25..." -ForegroundColor Yellow
    $jdkBase = Join-WinPath $env:LOCALAPPDATA "PZVR_ArmSwing\jdk25"
    Ensure-Dir $jdkBase
    $jdkZip = Join-WinPath $env:TEMP "temurin-jdk25-win-x64.zip"
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $url = "https://api.adoptium.net/v3/binary/latest/25/ga/windows/x64/jdk/hotspot/normal/eclipse?project=jdk"
    Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $jdkZip
    Write-Host "Extracting portable JDK 25 to $jdkBase ..." -ForegroundColor Cyan
    Expand-Archive -Path $jdkZip -DestinationPath $jdkBase -Force
    if (File-Exists $jdkZip) { [System.IO.File]::Delete($jdkZip) }
    $jdkPair = Find-Jdk25Pair
  }

  if (-not $jdkPair) {
    throw "Failed to locate JDK 25+ javac.exe / jar.exe even after portable JDK setup."
  }
  $javac = $jdkPair.Javac
  $jarExe = $jdkPair.Jar
  Write-Host "Using javac (Java $($jdkPair.Major)): $javac" -ForegroundColor Green

  # 2. Locate Project Zomboid & Steam Workshop dependencies (only scanning real ready drives)
  $steamRoots = @()
  $regSteam = (Get-ItemProperty "HKCU:\Software\Valve\Steam" -ErrorAction SilentlyContinue).SteamPath
  if (-not $regSteam) {
    $regSteam = (Get-ItemProperty "HKLM:\SOFTWARE\WOW6432Node\Valve\Steam" -ErrorAction SilentlyContinue).InstallPath
  }
  if ($regSteam) {
    $sp = $regSteam -replace '/','\'
    if (Dir-Exists $sp) { $steamRoots += $sp }
    $vdf = Join-WinPath $sp "steamapps\libraryfolders.vdf"
    if (File-Exists $vdf) {
      $vdfText = [System.IO.File]::ReadAllText($vdf)
      [regex]::Matches($vdfText, '"path"\s+"([^"]+)"') | ForEach-Object {
        $libPath = ($_.Groups[1].Value -replace '\\\\','\')
        if (Dir-Exists $libPath) { $steamRoots += $libPath }
      }
    }
  }
  foreach ($drv in [System.IO.DriveInfo]::GetDrives()) {
    if ($drv.IsReady -and $drv.DriveType -eq [System.IO.DriveType]::Fixed) {
      $r = $drv.RootDirectory.FullName
      foreach ($sub in @("Program Files (x86)\Steam", "Program Files\Steam", "SteamLibrary", "Steam")) {
        $cand = Join-WinPath $r $sub
        if (Dir-Exists $cand) { $steamRoots += $cand }
      }
    }
  }

  $wsRoots = @(); $pzDirs = @()
  foreach ($sr in ($steamRoots | Select-Object -Unique)) {
    if (-not (Dir-Exists $sr)) { continue }
    $ws = Join-WinPath $sr "steamapps\workshop\content\108600"
    if (Dir-Exists $ws) { $wsRoots += $ws }
    $pz = Join-WinPath $sr "steamapps\common\ProjectZomboid"
    if (Dir-Exists $pz) { $pzDirs += $pz }
  }
  $localModsDir = [System.IO.Path]::GetDirectoryName($modRoot)
  if (Dir-Exists $localModsDir) { $wsRoots += $localModsDir }

  function Find-FirstExisting([string[]]$candidates) {
    foreach ($p in $candidates) {
      if (File-Exists $p) { return $p }
    }
    return $null
  }

  function Find-FileIn([string[]]$dirs, [string]$fileName, [string[]]$preferredSubpaths) {
    $directHits = @()
    foreach ($d in $dirs) {
      if (-not (Dir-Exists $d)) { continue }
      foreach ($sub in $preferredSubpaths) {
        $directHits += (Join-WinPath $d $sub)
      }
    }
    $fast = Find-FirstExisting $directHits
    if ($fast) { return $fast }
    foreach ($d in $dirs) {
      if (-not (Dir-Exists $d)) { continue }
      try {
        $hits = [System.IO.Directory]::GetFiles($d, $fileName, [System.IO.SearchOption]::AllDirectories)
        if ($hits.Length -gt 0) { return $hits[0] }
      } catch {}
    }
    return $null
  }

  $pzJar   = Find-FileIn $pzDirs  "projectzomboid.jar" @("projectzomboid.jar", "java\projectzomboid.jar")
  $zbJar   = Find-FileIn $wsRoots "ZombieBuddy.jar"    @("3619862853\mods\ZombieBuddy\libs\ZombieBuddy.jar", "3619862853\mods\ZombieBuddy\42\media\java\ZombieBuddy.jar", "ZombieBuddy\libs\ZombieBuddy.jar")
  $pzvrJar = Find-FileIn $wsRoots "PZVR.jar"           @("3816830877\mods\PZVR\42\media\java\PZVR.jar", "PZVR\42\media\java\PZVR.jar")
  $vpJar   = Find-FileIn $wsRoots "Viewpoint.jar"      @("3809306528\mods\Viewpoint\42\media\java\client\Viewpoint.jar", "Viewpoint\42\media\java\client\Viewpoint.jar")

  if (-not $pzJar)   { throw "Could not find projectzomboid.jar in Steam libraries." }
  if (-not $zbJar)   { throw "Could not find ZombieBuddy.jar (Workshop 3619862853)." }
  if (-not $pzvrJar) { throw "Could not find PZVR.jar (Workshop 3816830877)." }
  if (-not $vpJar)   { throw "Could not find Viewpoint.jar (Workshop 3809306528)." }

  Write-Host "Found PZ:          $pzJar" -ForegroundColor Gray
  Write-Host "Found ZombieBuddy: $zbJar" -ForegroundColor Gray
  Write-Host "Found PZVR:        $pzvrJar" -ForegroundColor Gray
  Write-Host "Found Viewpoint:   $vpJar" -ForegroundColor Gray

  # 3. Compile PZVR_ArmSwing.jar (ZombieBuddy @Patch + OpenXR tracker + ArmSwingApi)
  $stageMain = Join-WinPath $env:TEMP "pzvr_armswing_main_classes"
  Clean-Dir $stageMain

  [string[]]$mainSources = @([System.IO.Directory]::GetFiles((Join-WinPath $modRoot "42\java_src"), "*.java", [System.IO.SearchOption]::AllDirectories))
  if ($mainSources.Length -eq 0) { throw "No Java sources found in 42\java_src" }

  $cpMain = "$pzJar;$zbJar;$pzvrJar"
  Write-Host "Compiling ZombieBuddy Java mod ($($mainSources.Length) files)..." -ForegroundColor Cyan
  & $javac -Xlint:-options -source 17 -target 17 -encoding UTF-8 -cp $cpMain -d $stageMain @mainSources
  if ($LASTEXITCODE -ne 0) { throw "javac failed for PZVR_ArmSwing.jar (exit $LASTEXITCODE)" }

  $outMainDir = Join-WinPath $modRoot "42\media\java\client"
  Ensure-Dir $outMainDir
  $outMainJar = Join-WinPath $outMainDir "PZVR_ArmSwing.jar"
  if (File-Exists $outMainJar) { [System.IO.File]::Delete($outMainJar) }
  & $jarExe cf $outMainJar -C $stageMain .
  if ($LASTEXITCODE -ne 0) { throw "jar failed for PZVR_ArmSwing.jar (exit $LASTEXITCODE)" }

  # 4. Compile PZVR-ArmSwing-Integration.jar (Viewpoint Addon UI + settings)
  $stageVp = Join-WinPath $env:TEMP "pzvr_armswing_vp_classes"
  Clean-Dir $stageVp

  [string[]]$vpSources = @([System.IO.Directory]::GetFiles((Join-WinPath $modRoot "42\viewpoint_src"), "*.java", [System.IO.SearchOption]::AllDirectories))
  if ($vpSources.Length -eq 0) { throw "No Java sources found in 42\viewpoint_src" }

  Write-Host "Compiling Viewpoint Addon JAR ($($vpSources.Length) file)..." -ForegroundColor Cyan
  & $javac -Xlint:-options -source 17 -target 17 -encoding UTF-8 -cp $vpJar -d $stageVp @vpSources
  if ($LASTEXITCODE -ne 0) { throw "javac failed for PZVR-ArmSwing-Integration.jar (exit $LASTEXITCODE)" }

  $outVpDir = Join-WinPath $modRoot "42\media\viewpoint\addons\pzvr.armswing"
  Ensure-Dir $outVpDir
  $outVpJar = Join-WinPath $outVpDir "PZVR-ArmSwing-Integration.jar"
  if (File-Exists $outVpJar) { [System.IO.File]::Delete($outVpJar) }
  & $jarExe cf $outVpJar -C $stageVp .
  if ($LASTEXITCODE -ne 0) { throw "jar failed for PZVR-ArmSwing-Integration.jar (exit $LASTEXITCODE)" }

  # 5. Verify both JAR archives are non-empty and readable zip/jar containers
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  foreach ($jarPath in @($outMainJar, $outVpJar)) {
    if (-not (File-Exists $jarPath)) { throw "Missing expected JAR output: $jarPath" }
    $zipCheck = [System.IO.Compression.ZipFile]::OpenRead($jarPath)
    try {
      $classCount = @($zipCheck.Entries | Where-Object { $_.FullName -like "*.class" }).Count
      if ($classCount -eq 0) { throw "JAR contains zero compiled .class files: $jarPath" }
      $len = (New-Object System.IO.FileInfo($jarPath)).Length
      Write-Host "Verified readable JAR: $jarPath ($len bytes, $classCount classes)" -ForegroundColor Green
    } finally {
      $zipCheck.Dispose()
    }
  }

  Write-Host ""
  Write-Host "BUILD SUCCEEDED!" -ForegroundColor Green
  Write-Host "Next: Launch Project Zomboid, enable PZVR_ArmSwing, and click ALLOW on ZombieBuddy's prompt!" -ForegroundColor Yellow
} catch {
  Write-Host ""
  Write-Host "BUILD FAILED (line $($_.InvocationInfo.ScriptLineNumber)): $($_.Exception.Message)" -ForegroundColor Red
  exit 1
} finally {
  try { if ($stageMain -and (Dir-Exists $stageMain)) { [System.IO.Directory]::Delete($stageMain, $true) } } catch {}
  try { if ($stageVp -and (Dir-Exists $stageVp)) { [System.IO.Directory]::Delete($stageVp, $true) } } catch {}
}
