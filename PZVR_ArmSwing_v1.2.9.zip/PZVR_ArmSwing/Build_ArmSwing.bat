@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo  PZVR Arm-Swing Java ^& Viewpoint Compiler (B42.22.2)
echo ============================================================
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Build_ArmSwing.ps1"
if errorlevel 1 (
    echo.
    echo [ERROR] Build failed! Read the red message above.
)
echo.
pause
