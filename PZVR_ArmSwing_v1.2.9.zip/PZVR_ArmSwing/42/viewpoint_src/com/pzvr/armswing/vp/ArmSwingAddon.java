package com.pzvr.armswing.vp;

import viewpoint.api.Addon;
import viewpoint.api.AddonContext;
import viewpoint.api.AddonSettings;
import viewpoint.api.lua.LuaExport;

public final class ArmSwingAddon implements Addon {
    private static volatile ArmSwingAddon live;

    private AddonContext context;

    @Override
    public void enable(AddonContext ctx) {
        this.context = ctx;
        live = this;
        AddonSettings settings = ctx.settings();

        settings.page()
            .tab("Arm-Swing")
            .section("Locomotion Thresholds")
            .setting("enabled")
            .setting("sensitivity")
            .setting("minSwingSpeed")
            .setting("runThreshold")
            .setting("sprintThreshold");
    }

    @Override
    public void disable() {
        if (live == this) live = null;
        context = null;
    }

    @LuaExport(name = "getSettingsCsv")
    public static String getSettingsCsv() {
        ArmSwingAddon a = live;
        if (a == null || a.context == null) return "";
        try {
            AddonSettings s = a.context.settings();
            return s.choice("enabled") + "|"
                + s.choice("sensitivity") + "|"
                + s.choice("minSwingSpeed") + "|"
                + s.choice("runThreshold") + "|"
                + s.choice("sprintThreshold");
        } catch (Throwable t) {
            return "";
        }
    }
}
