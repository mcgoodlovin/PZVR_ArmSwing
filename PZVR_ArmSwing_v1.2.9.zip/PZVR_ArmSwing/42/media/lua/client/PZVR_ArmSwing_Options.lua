--[[
  Mod Name: PZVR Arm-Swing Addon
  File: 42/media/lua/client/PZVR_ArmSwing_Options.lua
  Target: Project Zomboid Build 42.22.2 (PZAPI.ModOptions)
]]

pcall(require, "PZAPI/ModOptions")
pcall(require, "PZVR_ArmSwing_Config")

PZVR_ArmSwing = PZVR_ArmSwing or {}
local O = {}

local function install()
    if O.page or not PZAPI or not PZAPI.ModOptions or not PZVR_ArmSwing.Config then
        return
    end
    local cfg = PZVR_ArmSwing.Config
    local page = PZAPI.ModOptions:create("PZVR_ArmSwing", "PZVR Arm-Swing Addon")
    O.page = page

    page:addTitle("VR Arm-Swing Locomotion")
    O.openVrBtn = page:addButton("openVrMenu", "Open In-VR Floating Tuning Menu", "Opens the clickable In-VR floating panel right in your headset view (also available on your Off-Hand Palm Wheel -> Arm-Swing, or F8).", function()
        if PZVR_ArmSwing.OpenMenu then
            pcall(PZVR_ArmSwing.OpenMenu, true)
        end
    end)

    O.enabled = page:addTickBox("enabled", "Enable Arm-Swing Locomotion", cfg.Enabled ~= false, "Enable or disable Quest 3 arm-swing locomotion.")
    O.sensitivity = page:addSlider("sensitivity", "Swing Sensitivity", 0.5, 2.5, 0.05, cfg.Sensitivity or 1.0, "Multiplier applied to arm-swing controller speed.")
    O.minSwingSpeed = page:addSlider("minSwingSpeed", "Walk Gate (m/s)", 0.30, 1.60, 0.05, cfg.MinSwingSpeed or 0.75, "Arm speed needed to start walking. Standard VR default: 0.75 m/s.")
    O.runThreshold = page:addSlider("runThreshold", "Jog Threshold (m/s)", 0.90, 3.00, 0.05, cfg.RunThreshold or 1.55, "Rhythmic swinging speed required for vanilla Jog. Standard VR default: 1.55 m/s.")
    O.sprintThreshold = page:addSlider("sprintThreshold", "Sprint Threshold (m/s)", 1.50, 4.00, 0.05, cfg.SprintThreshold or 2.45, "Energetic pumping speed required for vanilla Sprint. Standard VR default: 2.45 m/s.")

    function page:apply()
        cfg.Enabled = O.enabled:getValue()
        cfg.Sensitivity = O.sensitivity:getValue()
        cfg.MinSwingSpeed = O.minSwingSpeed:getValue()
        cfg.RunThreshold = O.runThreshold:getValue()
        cfg.SprintThreshold = O.sprintThreshold:getValue()
        if PZVR_ArmSwing.SaveSettings then pcall(PZVR_ArmSwing.SaveSettings) end
        local api = _G.ArmSwingApi or ArmSwingApi
        if api then
            if api.setEnabled then pcall(api.setEnabled, cfg.Enabled ~= false) end
            if api.setSensitivity then pcall(api.setSensitivity, tonumber(cfg.Sensitivity) or 1.0) end
            if api.setMinSwingSpeed then pcall(api.setMinSwingSpeed, tonumber(cfg.MinSwingSpeed) or 0.75) end
            if api.setRunThreshold then pcall(api.setRunThreshold, tonumber(cfg.RunThreshold) or 1.55) end
            if api.setSprintThreshold then pcall(api.setSprintThreshold, tonumber(cfg.SprintThreshold) or 2.45) end
            if api.reloadSettings then pcall(api.reloadSettings) end
        end
        if PZVR_ArmSwing.Main and PZVR_ArmSwing.Main.SyncBridges then
            pcall(PZVR_ArmSwing.Main.SyncBridges)
        end
    end
end

install()
Events.OnGameBoot.Add(install)
