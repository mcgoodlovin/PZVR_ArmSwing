--[[
  Mod Name: PZVR Arm-Swing Addon
  File: 42/media/lua/client/PZVR_ArmSwing_Main.lua
  Target: Project Zomboid Build 42.22.2 | PZVR 0.2.x + Viewpoint 0.1.7 + ZombieBuddy
]]

pcall(require, "PZVR_ArmSwing_Config")

PZVR_ArmSwing = PZVR_ArmSwing or {}
PZVR_ArmSwing.Config = PZVR_ArmSwing.Config or {
    Enabled = true,
    Sensitivity = 1,
    MinSwingSpeed = 0.75,
    RunThreshold = 1.55,
    SprintThreshold = 2.45,
    Smoothing = 0.25,
    DecayRate = 0.25,
    AllowStickOverride = true
}
PZVR_ArmSwing.Runtime = PZVR_ArmSwing.Runtime or {
    VrStatus = "UNKNOWN",
    GaitMode = "IDLE"
}

local ArmSwing = {}
local rt = PZVR_ArmSwing.Runtime
local lastVpCsv = nil
local lastVpParts = nil
local lastSyncedCfgKey = nil
local lastVpPollMs = 0
local lastUiPollMs = 0

local function splitPipe(str)
    local out = {}
    if not str or str == "" then return out end
    for part in string.gmatch(str, "([^|]+)") do
        out[#out + 1] = part
    end
    return out
end

local function resolveViewpointAddon()
    local vp = Viewpoint and Viewpoint.Addons and Viewpoint.Addons['pzvr.armswing']
    if vp and vp.ArmSwingAddon then
        return vp.ArmSwingAddon
    end
    if ArmSwingVP and ArmSwingVP.ArmSwingAddon then
        return ArmSwingVP.ArmSwingAddon
    end
    return nil
end

function ArmSwing.SyncBridges()
    local cfg = PZVR_ArmSwing.Config
    local nowMs = getTimestampMs and getTimestampMs() or (lastVpPollMs + 250)

    if nowMs - lastVpPollMs >= 250 then
        lastVpPollMs = nowMs
        local vpAddon = resolveViewpointAddon()
        if vpAddon and vpAddon.getSettingsCsv then
            local okCsv, csv = pcall(vpAddon.getSettingsCsv)
            if okCsv and type(csv) == "string" and csv ~= "" then
                if lastVpCsv == nil then
                    lastVpCsv = csv
                    lastVpParts = splitPipe(csv)
                elseif csv ~= lastVpCsv then
                    lastVpCsv = csv
                    local parts = splitPipe(csv)
                    if #parts >= 5 then
                        local changed = false
                        if not lastVpParts or parts[1] ~= lastVpParts[1] then
                            cfg.Enabled = (string.lower(parts[1]) == "on")
                            changed = true
                        end
                        if not lastVpParts or parts[2] ~= lastVpParts[2] then
                            local sens = tonumber(parts[2]); if sens then cfg.Sensitivity = sens; changed = true end
                        end
                        if not lastVpParts or parts[3] ~= lastVpParts[3] then
                            local minSw = tonumber(parts[3]); if minSw then cfg.MinSwingSpeed = minSw; changed = true end
                        end
                        if not lastVpParts or parts[4] ~= lastVpParts[4] then
                            local runT = tonumber(parts[4]); if runT then cfg.RunThreshold = runT; changed = true end
                        end
                        if not lastVpParts or parts[5] ~= lastVpParts[5] then
                            local sprT = tonumber(parts[5]); if sprT then cfg.SprintThreshold = sprT; changed = true end
                        end
                        lastVpParts = parts
                        if changed and PZVR_ArmSwing.SaveSettings then pcall(PZVR_ArmSwing.SaveSettings) end
                    end
                end
            end
        end
    end

    local api = _G.ArmSwingApi or ArmSwingApi
    if api then
        local isEnabled = (cfg.Enabled ~= false)
        local sens = tonumber(cfg.Sensitivity) or 1.0
        local minSw = tonumber(cfg.MinSwingSpeed) or 0.75
        local runT = tonumber(cfg.RunThreshold) or 1.55
        local sprT = tonumber(cfg.SprintThreshold) or 2.45
        local cfgKey = (isEnabled and "1|" or "0|") .. tostring(sens) .. "|" .. tostring(minSw) .. "|" .. tostring(runT) .. "|" .. tostring(sprT)
        if cfgKey ~= lastSyncedCfgKey then
            lastSyncedCfgKey = cfgKey
            if api.setEnabled then pcall(api.setEnabled, isEnabled) end
            if api.setSensitivity then pcall(api.setSensitivity, sens) end
            if api.setMinSwingSpeed then pcall(api.setMinSwingSpeed, minSw) end
            if api.setRunThreshold then pcall(api.setRunThreshold, runT) end
            if api.setSprintThreshold then pcall(api.setSprintThreshold, sprT) end
            if api.configure then
                pcall(api.configure,
                    isEnabled,
                    sens,
                    runT,
                    sprT,
                    tonumber(cfg.Smoothing) or 0.25,
                    tonumber(cfg.DecayRate) or 0.25,
                    "both",
                    true,
                    minSw
                )
            end
        end

        if PZVR_ArmSwing.IsMenuOpen and PZVR_ArmSwing.IsMenuOpen() then
            if nowMs - lastUiPollMs >= 100 then
                lastUiPollMs = nowMs
                if api.gaitMode then
                    local okGt, gt = pcall(api.gaitMode)
                    if okGt and gt ~= nil then rt.GaitMode = tostring(gt) end
                end
                if VrApi and VrApi.status then
                    local okVr, vr = pcall(VrApi.status)
                    if okVr and vr ~= nil then rt.VrStatus = tostring(vr) end
                end
            end
        end
    else
        lastSyncedCfgKey = nil
    end
end

Events.OnGameStart.Add(function()
    if PZVR_ArmSwing.LoadSettings and not PZVR_ArmSwing.LoadSettings() then
        if PZVR_ArmSwing.SaveSettings then pcall(PZVR_ArmSwing.SaveSettings) end
    end
    pcall(ArmSwing.SyncBridges)
end)
Events.OnTickEvenPaused.Add(ArmSwing.SyncBridges)

PZVR_ArmSwing.Main = ArmSwing
return ArmSwing
