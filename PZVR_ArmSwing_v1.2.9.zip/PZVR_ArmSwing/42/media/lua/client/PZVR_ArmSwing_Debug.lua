--[[
  Mod Name: PZVR Arm-Swing Addon
  File: 42/media/lua/client/PZVR_ArmSwing_Debug.lua
  In-VR Visibility Fix:
    * Starts CLOSED on game start so PZVRHandUI.baseline never suppresses it inside VR_ACTIVE view mode.
    * Clears PZVRHandUI.baseline[panel.javaObject] whenever opened so PZVR renders it as a clickable 3D
      VrApi.floatingWindow right inside the Quest 3 VR headset!
    * Accessible directly inside VR via:
        1) Off-Hand Palm Wheel -> "Arm-Swing" slice
        2) Escape / Pause -> Options -> Mods -> "Open In-VR Floating Tuning Menu"
        3) [F8] key (VR or flat screen)
]]

pcall(require, "ISUI/ISPanel")
pcall(require, "ISUI/ISButton")
pcall(require, "ISUI/ISRadialMenu")
pcall(require, "PZVR_ArmSwing_Config")

PZVR_ArmSwing = PZVR_ArmSwing or {}
local PANEL_W = 500
local PANEL_H = 392
local HEADER_H = 32
local MAX_BAR_VEL = 4.0

-- Viewpoint UI Palette (dark translucent glass + warm amber/gold accents)
local VP_AMBER_R, VP_AMBER_G, VP_AMBER_B = 0.91, 0.65, 0.24
local VP_TEXT_R, VP_TEXT_G, VP_TEXT_B = 0.95, 0.96, 0.98
local VP_MUTED_R, VP_MUTED_G, VP_MUTED_B = 0.76, 0.78, 0.82

local function gaitColor(gait)
    if gait == "SPRINT" then return 0.94, 0.40, 0.28 end
    if gait == "JOG" then return VP_AMBER_R, VP_AMBER_G, VP_AMBER_B end
    if gait == "WALK" then return 0.95, 0.80, 0.42 end
    return 0.62, 0.65, 0.70
end

local function isBlockingUiOpen()
    if ViewpointInvScreen and ViewpointInvScreen.isUp then
        local ok, up = pcall(ViewpointInvScreen.isUp)
        if ok and up then return true end
    end
    if MainScreen and MainScreen.instance and MainScreen.instance.isVisible then
        local ok, vis = pcall(function() return MainScreen.instance:isVisible() end)
        if ok and vis then return true end
    end
    return false
end

local function clampVal(v, lo, hi)
    return math.max(lo, math.min(hi, v))
end

local function applyTuningChange()
    local cfg = PZVR_ArmSwing.Config or {}
    if PZVR_ArmSwing.SaveSettings then pcall(PZVR_ArmSwing.SaveSettings) end
    local api = _G.ArmSwingApi or ArmSwingApi
    if api then
        local isEnabled = (cfg.Enabled ~= false)
        if api.setEnabled then pcall(api.setEnabled, isEnabled) end
        if api.setSensitivity then pcall(api.setSensitivity, tonumber(cfg.Sensitivity) or 1.0) end
        if api.setMinSwingSpeed then pcall(api.setMinSwingSpeed, tonumber(cfg.MinSwingSpeed) or 0.75) end
        if api.setRunThreshold then pcall(api.setRunThreshold, tonumber(cfg.RunThreshold) or 1.55) end
        if api.setSprintThreshold then pcall(api.setSprintThreshold, tonumber(cfg.SprintThreshold) or 2.45) end
        if api.reloadSettings then pcall(api.reloadSettings) end
    end
    if PZVR_ArmSwing.Main and PZVR_ArmSwing.Main.SyncBridges then
        pcall(PZVR_ArmSwing.Main.SyncBridges)
    end
end

local BTN_ON_TEXT_COLOR = { r = 0.95, g = 0.96, b = 0.98, a = 1.0 }
local BTN_OFF_TEXT_COLOR = { r = 0.64, g = 0.66, b = 0.70, a = 1.0 }
local BTN_ON_BORDER_COLOR = { r = VP_AMBER_R, g = VP_AMBER_G, b = VP_AMBER_B, a = 0.70 }
local BTN_OFF_BORDER_COLOR = { r = 0.44, g = 0.28, b = 0.28, a = 0.75 }

local textWCache = {}
local textWCount = 0
local function measureTextW(txt)
    local cached = textWCache[txt]
    if cached then return cached end
    local width = string.len(txt) * 6.5
    if getTextManager then
        local ok, w = pcall(function() return getTextManager():MeasureStringX(UIFont.Small, txt) end)
        if ok and type(w) == "number" and w > 0 then
            width = w
        end
    end
    if textWCount >= 64 then
        textWCache = {}
        textWCount = 0
    end
    textWCache[txt] = width
    textWCount = textWCount + 1
    return width
end

local ArmSwingHUD = nil
local hudInstance = nil

local function makeBtn(self, x, y, w, h, title, fn)
    if not ISButton then return nil end
    local b = ISButton:new(x, y, w, h, title, self, fn)
    b:initialise()
    b:instantiate()
    b.backgroundColor = { r = 0.13, g = 0.14, b = 0.16, a = 0.90 }
    b.backgroundColorMouseOver = { r = 0.21, g = 0.23, b = 0.26, a = 0.96 }
    b.borderColor = { r = 0.28, g = 0.30, b = 0.34, a = 0.65 }
    b.textColor = { r = 0.94, g = 0.95, b = 0.97, a = 1.0 }
    b.vpActive = false
    local origRender = b.render
    if origRender then
        b.render = function(btnSelf)
            origRender(btnSelf)
            if btnSelf.vpActive then
                btnSelf:drawRect(0, 1, 3, btnSelf.height - 2, 0.98, VP_AMBER_R, VP_AMBER_G, VP_AMBER_B)
            end
        end
    end
    self:addChild(b)
    return b
end

if ISPanel then
    ArmSwingHUD = ISPanel:derive("PZVR_ArmSwing_HUD")

    function ArmSwingHUD:initialise()
        ISPanel.initialise(self)
        self.Type = "PZVR_ArmSwing_Menu"
        self.wantVisible = false
        self.customMoved = false
        self.draggingHeader = false
        self.dragOffsetX = 0
        self.dragOffsetY = 0
    end

    function ArmSwingHUD:createChildren()
        ISPanel.createChildren(self)

        -- Header Close Button (Viewpoint minimalist flat square X)
        self.closeBtn = makeBtn(self, self.width - 30, 5, 22, 22, "X", function()
            applyTuningChange()
            if PZVR_ArmSwing.CloseMenu then PZVR_ArmSwing.CloseMenu() end
        end)
        if self.closeBtn then
            self.closeBtn.backgroundColor = { r = 0.12, g = 0.13, b = 0.15, a = 0.92 }
            self.closeBtn.backgroundColorMouseOver = { r = 0.24, g = 0.25, b = 0.28, a = 0.98 }
            self.closeBtn.borderColor = { r = 0.28, g = 0.30, b = 0.34, a = 0.65 }
        end

        -- Row 1 (y=152): Full-width reliable ON/OFF toggle
        self.btnEnable = makeBtn(self, 18, 152, 464, 28, "Arm-Swing: ON", function()
            local cfg = PZVR_ArmSwing.Config
            if not cfg then
                PZVR_ArmSwing.Config = {}
                cfg = PZVR_ArmSwing.Config
            end
            cfg.Enabled = not (cfg.Enabled ~= false)
            applyTuningChange()
            if hudInstance and hudInstance.refreshButtons then
                hudInstance:refreshButtons()
            end
        end)

        -- Row 2 (y=188): Sensitivity (- / +) & Walk Gate (- / +)
        self.btnSensMinus = makeBtn(self, 18, 188, 34, 28, "-", function()
            local cfg = PZVR_ArmSwing.Config
            cfg.Sensitivity = clampVal((cfg.Sensitivity or 1.0) - 0.05, 0.50, 2.50)
            applyTuningChange()
        end)
        self.btnSensPlus = makeBtn(self, 212, 188, 34, 28, "+", function()
            local cfg = PZVR_ArmSwing.Config
            cfg.Sensitivity = clampVal((cfg.Sensitivity or 1.0) + 0.05, 0.50, 2.50)
            applyTuningChange()
        end)

        self.btnWalkMinus = makeBtn(self, 254, 188, 34, 28, "-", function()
            local cfg = PZVR_ArmSwing.Config
            cfg.MinSwingSpeed = clampVal((cfg.MinSwingSpeed or 0.75) - 0.05, 0.30, 1.60)
            applyTuningChange()
        end)
        self.btnWalkPlus = makeBtn(self, 448, 188, 34, 28, "+", function()
            local cfg = PZVR_ArmSwing.Config
            cfg.MinSwingSpeed = clampVal((cfg.MinSwingSpeed or 0.75) + 0.05, 0.30, 1.60)
            if (cfg.RunThreshold or 1.55) < cfg.MinSwingSpeed + 0.35 then
                cfg.RunThreshold = math.min(3.00, cfg.MinSwingSpeed + 0.35)
                if (cfg.SprintThreshold or 2.45) < cfg.RunThreshold + 0.45 then
                    cfg.SprintThreshold = math.min(4.00, cfg.RunThreshold + 0.45)
                end
            end
            applyTuningChange()
        end)

        -- Row 3 (y=224): Jog Threshold (- / +) & Sprint Threshold (- / +)
        self.btnJogMinus = makeBtn(self, 18, 224, 34, 28, "-", function()
            local cfg = PZVR_ArmSwing.Config
            local floorV = math.max(0.80, (cfg.MinSwingSpeed or 0.75) + 0.35)
            cfg.RunThreshold = clampVal((cfg.RunThreshold or 1.55) - 0.05, floorV, 3.00)
            if (cfg.SprintThreshold or 2.45) < cfg.RunThreshold + 0.45 then
                cfg.SprintThreshold = cfg.RunThreshold + 0.45
            end
            applyTuningChange()
        end)
        self.btnJogPlus = makeBtn(self, 212, 224, 34, 28, "+", function()
            local cfg = PZVR_ArmSwing.Config
            cfg.RunThreshold = clampVal((cfg.RunThreshold or 1.55) + 0.05, 0.80, 3.00)
            if (cfg.SprintThreshold or 2.45) < cfg.RunThreshold + 0.45 then
                cfg.SprintThreshold = math.min(4.00, cfg.RunThreshold + 0.45)
            end
            applyTuningChange()
        end)

        self.btnSprMinus = makeBtn(self, 254, 224, 34, 28, "-", function()
            local cfg = PZVR_ArmSwing.Config
            local floorV = math.max(1.30, (cfg.RunThreshold or 1.55) + 0.45)
            cfg.SprintThreshold = clampVal((cfg.SprintThreshold or 2.45) - 0.05, floorV, 4.00)
            applyTuningChange()
        end)
        self.btnSprPlus = makeBtn(self, 448, 224, 34, 28, "+", function()
            local cfg = PZVR_ArmSwing.Config
            cfg.SprintThreshold = clampVal((cfg.SprintThreshold or 2.45) + 0.05, 1.30, 4.00)
            applyTuningChange()
        end)

        -- Row 4 (y=262): Clean 2-button action row (Reset Defaults & Save & Close)
        self.btnReset = makeBtn(self, 18, 262, 228, 28, "Reset Defaults", function()
            if PZVR_ArmSwing.ResetDefaults then pcall(PZVR_ArmSwing.ResetDefaults) end
            applyTuningChange()
            if hudInstance and hudInstance.refreshButtons then
                hudInstance:refreshButtons()
            end
        end)
        self.btnDone = makeBtn(self, 254, 262, 228, 28, "Save & Close", function()
            applyTuningChange()
            if PZVR_ArmSwing.CloseMenu then PZVR_ArmSwing.CloseMenu() end
        end)
        if self.btnDone then
            self.btnDone.borderColor = { r = VP_AMBER_R, g = VP_AMBER_G, b = VP_AMBER_B, a = 0.70 }
        end
    end

    function ArmSwingHUD:refreshButtons()
        local cfg = PZVR_ArmSwing.Config or {}
        local enabled = (cfg.Enabled ~= false)
        if self.btnEnable and self.btnEnable._lastEnabled ~= enabled then
            self.btnEnable._lastEnabled = enabled
            local nextTitle = enabled and "Arm-Swing: ON" or "Arm-Swing: OFF"
            self.btnEnable:setTitle(nextTitle)
            self.btnEnable.vpActive = enabled
            self.btnEnable.textColor = enabled and BTN_ON_TEXT_COLOR or BTN_OFF_TEXT_COLOR
            self.btnEnable.borderColor = enabled and BTN_ON_BORDER_COLOR or BTN_OFF_BORDER_COLOR
        end
    end

    function ArmSwingHUD:onMouseDown(x, y)
        if y <= HEADER_H and x < self.width - 36 then
            self.draggingHeader = true
            self.customMoved = true
            self.dragOffsetX = x
            self.dragOffsetY = y
            return true
        end
        return ISPanel.onMouseDown(self, x, y)
    end

    function ArmSwingHUD:onMouseMove(dx, dy)
        if self.draggingHeader and (not PZVRHandUI or not PZVRHandUI.active or (VrApi and VrApi.fullHud and VrApi.fullHud())) then
            local sw = (getCore and getCore():getScreenWidth()) or 1280
            local sh = (getCore and getCore():getScreenHeight()) or 720
            local nx = math.max(8, math.min(sw - self.width - 8, self:getX() + dx))
            local ny = math.max(8, math.min(sh - self.height - 8, self:getY() + dy))
            self:setX(nx)
            self:setY(ny)
            return true
        end
        return ISPanel.onMouseMove(self, dx, dy)
    end

    function ArmSwingHUD:onMouseUp(x, y)
        self.draggingHeader = false
        return ISPanel.onMouseUp(self, x, y)
    end

    function ArmSwingHUD:onMouseUpOutside(x, y)
        self.draggingHeader = false
        return ISPanel.onMouseUpOutside(self, x, y)
    end

    function ArmSwingHUD:prerender()
        self:refreshButtons()
        if not self.customMoved and getCore then
            local sw = getCore():getScreenWidth() or 1280
            local sh = getCore():getScreenHeight() or 720
            self:setX(math.max(16, math.floor((sw - self.width) / 2)))
            self:setY(math.max(24, math.floor((sh - self.height) / 2) - 40))
        end
        ISPanel.prerender(self)
    end

    -- Viewpoint 10-pip segmented square meter with threshold tick marks underneath
    function ArmSwingHUD:drawMeter(label, val, x, y, fr, fg, fb, minMark, runMark, sprMark, rightText)
        self:drawText(label, x + 8, y, VP_MUTED_R, VP_MUTED_G, VP_MUTED_B, 1.0, UIFont.Small)
        local numPips = 10
        local pipW = 13
        local pipH = 10
        local gap = 5
        local bx = x + 126
        local totalW = numPips * pipW + (numPips - 1) * gap
        local ratio = math.max(0.0, math.min(1.0, val / MAX_BAR_VEL))
        local filledPips = 0
        if val > 0.04 then
            filledPips = math.max(1, math.min(numPips, math.floor(ratio * numPips + 0.5)))
        end

        for i = 1, numPips do
            local px = bx + (i - 1) * (pipW + gap)
            if i <= filledPips then
                self:drawRect(px, y + 1, pipW, pipH, 0.96, fr, fg, fb)
            else
                self:drawRect(px, y + 1, pipW, pipH, 0.65, 0.28, 0.31, 0.36)
            end
        end

        -- Proportional track + threshold ticks beneath the 10 squares (covers full 0.00..4.00 m/s scale)
        self:drawRect(bx, y + pipH + 3, totalW, 2, 0.25, 0.32, 0.36, 0.42)
        local fillW = math.floor(totalW * ratio + 0.5)
        if fillW > 0 then
            self:drawRect(bx, y + pipH + 3, fillW, 2, 0.90, fr, fg, fb)
        end
        if minMark then
            local mx = bx + math.floor(totalW * math.min(1.0, minMark / MAX_BAR_VEL))
            self:drawRect(mx, y + pipH + 1, 2, 4, 0.92, 0.94, 0.95, 0.98)
        end
        if runMark then
            local rx = bx + math.floor(totalW * math.min(1.0, runMark / MAX_BAR_VEL))
            self:drawRect(rx, y + pipH + 1, 2, 4, 0.95, VP_AMBER_R, VP_AMBER_G, VP_AMBER_B)
        end
        if sprMark then
            local sx = bx + math.floor(totalW * math.min(1.0, sprMark / MAX_BAR_VEL))
            self:drawRect(sx, y + pipH + 1, 2, 4, 0.95, 0.94, 0.40, 0.28)
        end

        self:drawText(rightText or string.format("%.2f m/s", val), bx + totalW + 14, y, VP_TEXT_R, VP_TEXT_G, VP_TEXT_B, 1.0, UIFont.Small)
    end

    function ArmSwingHUD:drawCenteredValueBox(x, y, w, h, text, tr, tg, tb)
        self:drawRect(x, y, w, h, 0.85, 0.08, 0.09, 0.11)
        self:drawRectBorder(x, y, w, h, 0.55, 0.26, 0.28, 0.32)
        local tw = measureTextW(text)
        local tx = x + math.max(6, math.floor((w - tw) / 2))
        self:drawText(text, tx, y + 6, tr, tg, tb, 1.0, UIFont.Small)
    end

    function ArmSwingHUD:render()
        ISPanel.render(self)
        local rt = PZVR_ArmSwing.Runtime or {}
        local cfg = PZVR_ArmSwing.Config or {}
        local gait = tostring(rt.GaitMode or "IDLE")
        if cfg.Enabled == false then gait = "OFF" end
        local gr, gg, gb = gaitColor(gait)

        -- Subtle Viewpoint left rail & active amber edge bar
        self:drawRect(1, 1, 8, self.height - 2, 0.72, 0.03, 0.04, 0.05)
        self:drawRect(9, 1, 1, self.height - 2, 0.25, 0.40, 0.44, 0.48)
        self:drawRect(1, 4, 3, HEADER_H - 6, 0.98, VP_AMBER_R, VP_AMBER_G, VP_AMBER_B)

        -- Header Bar (matching Viewpoint two-tone header style; version hidden)
        self:drawRect(10, 1, self.width - 11, HEADER_H, 0.72, 0.04, 0.05, 0.07)
        self:drawRect(10, HEADER_H, self.width - 11, 1, 0.25, 0.50, 0.54, 0.60)
        local vrW = measureTextW("VR ")
        self:drawText("VR", 18, 8, VP_AMBER_R, VP_AMBER_G, VP_AMBER_B, 1.0, UIFont.Small)
        self:drawText("Arm-Swing Locomotion", 18 + vrW, 8, VP_TEXT_R, VP_TEXT_G, VP_TEXT_B, 1.0, UIFont.Small)

        -- Subtle Gait Status & XR Indicator
        local badgeX = 304
        self:drawRect(badgeX, 6, 82, 20, 0.85, 0.09, 0.10, 0.12)
        self:drawRectBorder(badgeX, 6, 82, 20, 0.70, gr, gg, gb)
        local gwTxt = measureTextW(gait)
        self:drawText(gait, badgeX + math.max(6, math.floor((82 - gwTxt) / 2)), 8, gr, gg, gb, 1.0, UIFont.Small)

        local xrTxt = (rt.VrStatus == "VR_ACTIVE") and "XR:ON" or "XR:OFF"
        self:drawText(xrTxt, 396, 8, VP_MUTED_R, VP_MUTED_G, VP_MUTED_B, 1.0, UIFont.Small)

        local sens = cfg.Sensitivity or 1.0
        local minS = cfg.MinSwingSpeed or 0.75
        local runT = cfg.RunThreshold or 1.55
        local sprT = cfg.SprintThreshold or 2.45

        if self._lastSens ~= sens then
            self._lastSens = sens
            self._sensTxt = string.format("Sens: %.2fx", sens)
        end
        if self._lastMinS ~= minS then
            self._lastMinS = minS
            self._minRateTxt = string.format("%.2f m/s", minS)
            self._walkBoxTxt = string.format("Walk: %.2f m/s", minS)
        end
        if self._lastRunT ~= runT then
            self._lastRunT = runT
            self._runRateTxt = string.format("%.2f m/s", runT)
            self._jogBoxTxt = string.format("Jog: %.2f m/s", runT)
        end
        if self._lastSprT ~= sprT then
            self._lastSprT = sprT
            self._sprRateTxt = string.format("%.2f m/s", sprT)
            self._sprBoxTxt = string.format("Sprint: %.2f m/s", sprT)
        end

        -- Category 1: Visual Threshold Scale (Amber header + hairline divider)
        self:drawText("Speed Thresholds", 18, 40, VP_AMBER_R, VP_AMBER_G, VP_AMBER_B, 1.0, UIFont.Small)
        self:drawRect(18, 56, self.width - 36, 1, 0.22, 0.50, 0.54, 0.60)

        self:drawMeter("Walk Gate", minS, 18, 62, 0.94, 0.90, 0.74, nil, nil, nil, self._minRateTxt)
        self:drawMeter("Jog Speed", runT, 18, 82, VP_AMBER_R, VP_AMBER_G, VP_AMBER_B, nil, nil, nil, self._runRateTxt)
        self:drawMeter("Sprint Speed", sprT, 18, 102, 0.94, 0.40, 0.28, nil, nil, nil, self._sprRateTxt)

        -- Category 2: Settings
        self:drawText("Settings", 18, 128, VP_AMBER_R, VP_AMBER_G, VP_AMBER_B, 1.0, UIFont.Small)
        self:drawRect(18, 144, self.width - 36, 1, 0.22, 0.50, 0.54, 0.60)

        -- Tuning value cells centered between - / + buttons
        self:drawCenteredValueBox(54, 188, 156, 28, self._sensTxt, VP_TEXT_R, VP_TEXT_G, VP_TEXT_B)
        self:drawCenteredValueBox(290, 188, 156, 28, self._walkBoxTxt, 0.94, 0.90, 0.74)
        self:drawCenteredValueBox(54, 224, 156, 28, self._jogBoxTxt, VP_AMBER_R, VP_AMBER_G, VP_AMBER_B)
        self:drawCenteredValueBox(290, 224, 156, 28, self._sprBoxTxt, 0.95, 0.46, 0.34)

        -- Category 3: Calibration Instructions (Simple guide for players)
        self:drawText("How to Calibrate", 18, 300, VP_AMBER_R, VP_AMBER_G, VP_AMBER_B, 1.0, UIFont.Small)
        self:drawRect(18, 316, self.width - 36, 1, 0.22, 0.50, 0.54, 0.60)
        self:drawText("1. Raise Walk if casual arm sway or turning causes unwanted steps.", 18, 322, 0.76, 0.78, 0.82, 1.0, UIFont.Small)
        self:drawText("2. Lower Jog or Sprint if reaching faster speeds feels too tiring.", 18, 338, 0.76, 0.78, 0.82, 1.0, UIFont.Small)
        self:drawText("3. Tune Sens for overall arm effort, then click Save & Close.", 18, 354, 0.68, 0.70, 0.75, 1.0, UIFont.Small)

        -- Subtle translucent author mark in bottom-right corner
        local authorTxt = "mcgoodlovin"
        local authorW = measureTextW(authorTxt)
        self:drawText(authorTxt, self.width - authorW - 18, self.height - 18, 0.72, 0.74, 0.78, 0.34, UIFont.Small)
    end
end

local function ensureHUD()
    if hudInstance or not ArmSwingHUD then return end
    local sw = (getCore and getCore():getScreenWidth()) or 1280
    local sh = (getCore and getCore():getScreenHeight()) or 720
    local startX = math.max(16, math.floor((sw - PANEL_W) / 2))
    local startY = math.max(24, math.floor((sh - PANEL_H) / 2) - 40)
    hudInstance = ArmSwingHUD:new(startX, startY, PANEL_W, PANEL_H)
    hudInstance.backgroundColor = { r = 0.05, g = 0.06, b = 0.08, a = 0.84 }
    hudInstance.borderColor = { r = 0.25, g = 0.27, b = 0.30, a = 0.55 }
    hudInstance:initialise()
    hudInstance:instantiate()
    hudInstance:setVisible(false)
end

local function clearPzvrBaseline()
    if hudInstance and hudInstance.javaObject and PZVRHandUI and PZVRHandUI.baseline then
        PZVRHandUI.baseline[hudInstance.javaObject] = nil
    end
end

function PZVR_ArmSwing.IsMenuOpen()
    return hudInstance ~= nil and hudInstance.wantVisible == true
end

function PZVR_ArmSwing.OpenMenu(forceOpen)
    ensureHUD()
    if not hudInstance then return end
    if forceOpen ~= false then
        hudInstance.wantVisible = true
    end
    if VrApi and VrApi.status then
        local okVr, vr = pcall(VrApi.status)
        if okVr and vr ~= nil then
            PZVR_ArmSwing.Runtime = PZVR_ArmSwing.Runtime or {}
            PZVR_ArmSwing.Runtime.VrStatus = tostring(vr)
        end
    end
    clearPzvrBaseline()
    if not isBlockingUiOpen() then
        local ui = UIManager and UIManager.getUI and UIManager.getUI()
        if ui and not ui:contains(hudInstance.javaObject) then
            hudInstance:addToUIManager()
        end
        hudInstance:setVisible(true)
        if hudInstance.bringToTop then
            pcall(function() hudInstance:bringToTop() end)
        end
    end
end

function PZVR_ArmSwing.CloseMenu()
    if not hudInstance then return end
    hudInstance.wantVisible = false
    hudInstance:setVisible(false)
    if hudInstance.removeFromUIManager then
        pcall(function() hudInstance:removeFromUIManager() end)
    end
    clearPzvrBaseline()
end

function PZVR_ArmSwing.ToggleMenu()
    ensureHUD()
    if not hudInstance then return end
    if hudInstance.wantVisible then
        PZVR_ArmSwing.CloseMenu()
    else
        PZVR_ArmSwing.OpenMenu(true)
    end
end

local function syncHudVisibility()
    if not hudInstance then return end
    if not hudInstance.wantVisible then
        if hudInstance:getIsVisible() then
            hudInstance:setVisible(false)
            if hudInstance.removeFromUIManager then
                pcall(function() hudInstance:removeFromUIManager() end)
            end
        end
        return
    end
    local blocked = isBlockingUiOpen()
    if blocked then
        if hudInstance:getIsVisible() then
            hudInstance:setVisible(false)
        end
    else
        clearPzvrBaseline()
        local ui = UIManager and UIManager.getUI and UIManager.getUI()
        if ui and not ui:contains(hudInstance.javaObject) then
            hudInstance:addToUIManager()
        end
        if not hudInstance:getIsVisible() then
            hudInstance:setVisible(true)
            if hudInstance.bringToTop then
                pcall(function() hudInstance:bringToTop() end)
            end
        end
    end
end

-- Hook PZVR's Off-Hand Palm Wheel so users can open the Floating VR Tuning Menu right inside the headset
local palmWheelHooked = false
local cachedWheelIcon = nil
local function installPalmWheelHook()
    if palmWheelHooked or not PZVRHandUI or not PZVRHandUI.openWheel then return end
    palmWheelHooked = true
    local nativeOpenWheel = PZVRHandUI.openWheel
    PZVRHandUI.openWheel = function(p, submenu, page, ...)
        if not submenu and (page == nil or page == 1) and ISRadialMenu and ISRadialMenu.initialise then
            local origInit = ISRadialMenu.initialise
            ISRadialMenu.initialise = function(wheelSelf, ...)
                if wheelSelf and wheelSelf.pzvrLabels and type(wheelSelf.pzvrLabels) == "table" and not wheelSelf.pzvrArmSwingAdded then
                    wheelSelf.pzvrArmSwingAdded = true
                    if not cachedWheelIcon and getTexture then
                        cachedWheelIcon = getTexture("media/ui/Moodle_Icon_Endurance.png")
                    end
                    wheelSelf.pzvrLabels[#wheelSelf.pzvrLabels + 1] = "Arm-Swing"
                    wheelSelf:addSlice("Arm-Swing", cachedWheelIcon, function()
                        if PZVR_ArmSwing and PZVR_ArmSwing.ToggleMenu then
                            PZVR_ArmSwing.ToggleMenu()
                        end
                    end)
                end
                return origInit(wheelSelf, ...)
            end
            local ok, res = pcall(nativeOpenWheel, p, submenu, page, ...)
            ISRadialMenu.initialise = origInit
            if not ok then error(res) end
            return res
        end
        return nativeOpenWheel(p, submenu, page, ...)
    end
end

local function onKeyPressed(key)
    if Keyboard and key == Keyboard.KEY_F8 then
        PZVR_ArmSwing.ToggleMenu()
    end
end

Events.OnGameStart.Add(installPalmWheelHook)
Events.OnCreatePlayer.Add(function()
    installPalmWheelHook()
    ensureHUD()
end)
Events.OnTickEvenPaused.Add(syncHudVisibility)
Events.OnKeyPressed.Add(onKeyPressed)
