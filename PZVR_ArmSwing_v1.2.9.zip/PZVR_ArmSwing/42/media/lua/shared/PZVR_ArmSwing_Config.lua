--[[
  Mod Name: PZVR Arm-Swing Addon
  File: 42/media/lua/shared/PZVR_ArmSwing_Config.lua
  Target: Project Zomboid Build 42.22.2 (PZVR + Project Viewpoint + ZombieBuddy)
]]

PZVR_ArmSwing = PZVR_ArmSwing or {}

PZVR_ArmSwing.Defaults = {
    Enabled = true,
    Sensitivity = 1,
    MinSwingSpeed = 0.75,
    RunThreshold = 1.55,
    SprintThreshold = 2.45,
    Smoothing = 0.25,
    DecayRate = 0.25,
    AllowStickOverride = true
}

PZVR_ArmSwing.Config = PZVR_ArmSwing.Config or {}
for k, v in pairs(PZVR_ArmSwing.Defaults) do
    if PZVR_ArmSwing.Config[k] == nil then
        PZVR_ArmSwing.Config[k] = v
    end
end

PZVR_ArmSwing.Runtime = PZVR_ArmSwing.Runtime or {
    VrStatus = "UNKNOWN",
    GaitMode = "IDLE"
}

function PZVR_ArmSwing.SaveSettings()
    if not getFileWriter then return false end
    local cfg = PZVR_ArmSwing.Config
    local ok, writer = pcall(getFileWriter, "PZVR_ArmSwing_Settings_v3.txt", true, false)
    if ok and writer then
        pcall(function()
            writer:write("Enabled=" .. tostring(cfg.Enabled ~= false) .. "\r\n")
            writer:write(string.format("Sensitivity=%.2f\r\n", tonumber(cfg.Sensitivity) or 1.0))
            writer:write(string.format("MinSwingSpeed=%.2f\r\n", tonumber(cfg.MinSwingSpeed) or 0.75))
            writer:write(string.format("RunThreshold=%.2f\r\n", tonumber(cfg.RunThreshold) or 1.55))
            writer:write(string.format("SprintThreshold=%.2f\r\n", tonumber(cfg.SprintThreshold) or 2.45))
        end)
        pcall(function() writer:close() end)
        return true
    end
    return false
end

function PZVR_ArmSwing.LoadSettings()
    if not getFileReader then return false end
    local ok, reader = pcall(getFileReader, "PZVR_ArmSwing_Settings_v3.txt", false)
    if ok and reader then
        local cfg = PZVR_ArmSwing.Config
        while true do
            local line = reader:readLine()
            if not line then break end
            local k, v = string.match(line, "^([^=]+)=(.+)$")
            if k and v then
                v = string.gsub(v, "[\r\n]+$", "")
                if k == "Enabled" then cfg.Enabled = (string.lower(v) == "true")
                elseif k == "Sensitivity" then local n = tonumber(v); if n then cfg.Sensitivity = n end
                elseif k == "MinSwingSpeed" then local n = tonumber(v); if n then cfg.MinSwingSpeed = n end
                elseif k == "RunThreshold" then local n = tonumber(v); if n then cfg.RunThreshold = n end
                elseif k == "SprintThreshold" then local n = tonumber(v); if n then cfg.SprintThreshold = n end
                end
            end
        end
        pcall(function() reader:close() end)
        return true
    end
    return false
end

function PZVR_ArmSwing.ResetDefaults()
    for k, v in pairs(PZVR_ArmSwing.Defaults) do
        PZVR_ArmSwing.Config[k] = v
    end
    PZVR_ArmSwing.SaveSettings()
    if PZVR_ArmSwing.Main and PZVR_ArmSwing.Main.SyncBridges then
        pcall(PZVR_ArmSwing.Main.SyncBridges)
    end
end

pcall(PZVR_ArmSwing.LoadSettings)
print("[PZVR_ArmSwing] Config loaded (Build 42.22.2).")
return PZVR_ArmSwing.Config
