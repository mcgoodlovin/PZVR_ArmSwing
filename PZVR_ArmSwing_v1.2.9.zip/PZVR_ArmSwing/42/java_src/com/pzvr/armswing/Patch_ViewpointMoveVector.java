package com.pzvr.armswing;

import me.zed_0xff.zombie_buddy.Patch;
import zombie.characters.IsoPlayer;
import zombie.iso.Vector2;

@Patch(className = "viewpoint.input.Controls", methodName = "moveVector")
public class Patch_ViewpointMoveVector {
    @Patch.OnExit
    public static void exit(@Patch.Argument(0) IsoPlayer player, @Patch.Argument(1) Vector2 vector) {
        ArmSwingState.applyToMoveVector(player, vector, false);
    }
}
