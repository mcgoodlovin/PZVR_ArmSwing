package com.pzvr.armswing;

import me.zed_0xff.zombie_buddy.Patch;

@Patch(className = "zombie.input.GameKeyboard", methodName = "isKeyDown", strictMatch = true)
public class Patch_SpeedKeys {
    @Patch.OnExit
    public static void exit(@Patch.Argument(0) int key, @Patch.Return(readOnly = false) boolean result) {
        if (!result && ArmSwingState.enabled && ArmSwingState.drivingThisTick) {
            int want = ArmSwingState.desiredSpeedKey();
            if (want > 0 && key == want) {
                result = true;
            }
        }
    }
}
