package com.pzvr.armswing;

import me.zed_0xff.zombie_buddy.Patch;

@Patch(className = "zombie.core.Core", methodName = "isToggleToSprint", strictMatch = true)
public class Patch_ToggleSprint {
    @Patch.OnExit
    public static void exit(@Patch.Return(readOnly = false) boolean result) {
        if (result && ArmSwingState.enabled && ArmSwingState.drivingThisTick) {
            result = false;
        }
    }
}
