package com.pzvr.armswing;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.lang.reflect.Method;
import local.pzvr.Engine;
import local.pzvr.Math3;
import local.pzvr.XrBackend;
import zombie.characters.IsoPlayer;
import zombie.core.Core;
import zombie.iso.Vector2;

/**
 * Computes head-relative 3D velocity from Quest 3 controllers via PZVR's Engine.latest OpenXR frame
 * and supplies smooth walk/run/sprint locomotion vectors to Viewpoint / PZVR hooks.
 */
public final class ArmSwingState {
    public static volatile boolean enabled = true;
    public static volatile double sensitivity = 1;
    public static volatile double minSwingSpeed = 0.75;
    public static volatile double runThreshold = 1.55;
    public static volatile double sprintThreshold = 2.45;
    public static volatile double smoothing = 0.25;
    public static volatile double decayRate = 0.25;
    public static volatile boolean allowStickOverride = true;

    public static volatile double leftVel = 0.0;
    public static volatile double rightVel = 0.0;
    public static volatile double swingEnergy = 0.0;
    public static volatile String gaitMode = "IDLE";
    public static volatile boolean running = false;
    public static volatile boolean sprinting = false;
    public static volatile boolean drivingThisTick = false;

    private static long lastFrameTime = -1L;
    private static long lastSampleNanos = 0L;
    private static long lastTickNanos = 0L;
    private static boolean hasPrevLeft = false;
    private static boolean hasPrevRight = false;
    private static boolean engaged = false;
    private static boolean wasDrivingLastTick = false;
    private static double leftRecentPeak = 0.0;
    private static double rightRecentPeak = 0.0;
    private static double strideVel = 0.0;
    private static double reversalHoldTimer = 0.0;
    private static double smoothedWalkScale = 0.65;
    private static double prevWorldLx, prevWorldLy, prevWorldLz;
    private static double prevWorldRx, prevWorldRy, prevWorldRz;
    private static double prevRelLx, prevRelLy, prevRelLz;
    private static double prevRelRx, prevRelRy, prevRelRz;
    private static int cachedRunKey = -1;
    private static int cachedSprintKey = -1;
    private static long lastSettingsCheckNanos = 0L;
    private static long lastSettingsSig = -1L;
    private static File cachedSettingsFile = null;

    // Preserved per-frame animation root-motion displacement (avoids Flash-speed 1.0 tile/frame bug)
    private static float savedRootX = 0.0f;
    private static float savedRootY = 0.0f;
    private static IsoPlayer savedRootPlayer = null;
    private static boolean savedRootActive = false;

    private ArmSwingState() {}

    private static double clampSetting(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static File resolveSettingsFile() {
        if (cachedSettingsFile != null && cachedSettingsFile.exists()) {
            return cachedSettingsFile;
        }
        String relLua = "Lua" + File.separator + "PZVR_ArmSwing_Settings_v3.txt";
        try {
            Class<?> zfsCls = Class.forName("zombie.ZomboidFileSystem");
            Object zfsInst = zfsCls.getField("instance").get(null);
            if (zfsInst != null) {
                Method m = zfsCls.getMethod("getCacheDirSub", String.class);
                Object sub = m.invoke(zfsInst, relLua);
                if (sub != null) {
                    File f = new File(sub.toString());
                    if (f.exists()) {
                        cachedSettingsFile = f;
                        return f;
                    }
                }
            }
        } catch (Throwable ignored) {}
        try {
            Method mDoc = Core.class.getMethod("getMyDocumentFolder");
            Object docDir = mDoc.invoke(null);
            if (docDir != null) {
                File f = new File(new File(docDir.toString(), "Lua"), "PZVR_ArmSwing_Settings_v3.txt");
                if (f.exists()) {
                    cachedSettingsFile = f;
                    return f;
                }
            }
        } catch (Throwable ignored) {}
        try {
            String home = System.getProperty("user.home", "");
            if (!home.isEmpty()) {
                File f = new File(new File(new File(home, "Zomboid"), "Lua"), "PZVR_ArmSwing_Settings_v3.txt");
                if (f.exists()) {
                    cachedSettingsFile = f;
                    return f;
                }
            }
        } catch (Throwable ignored) {}
        return null;
    }

    public static synchronized void reloadSettingsFromDisk(boolean force) {
        try {
            long nowNanos = System.nanoTime();
            if (!force && lastSettingsCheckNanos != 0L && nowNanos - lastSettingsCheckNanos < 150_000_000L) {
                return;
            }
            lastSettingsCheckNanos = nowNanos;
            File f = resolveSettingsFile();
            if (f == null || !f.exists()) return;
            long sig = f.lastModified() * 31L + f.length();
            if (!force && sig == lastSettingsSig) return;

            boolean wasEnabled = enabled;
            try (BufferedReader br = new BufferedReader(new FileReader(f))) {
                String line;
                while ((line = br.readLine()) != null) {
                    int eq = line.indexOf('=');
                    if (eq <= 0) continue;
                    String k = line.substring(0, eq).trim();
                    String v = line.substring(eq + 1).trim();
                    if ("Enabled".equals(k)) {
                        enabled = !"false".equalsIgnoreCase(v);
                    } else if ("Sensitivity".equals(k)) {
                        sensitivity = clampSetting(Double.parseDouble(v), 0.25, 3.0);
                    } else if ("MinSwingSpeed".equals(k)) {
                        minSwingSpeed = clampSetting(Double.parseDouble(v), 0.25, 2.0);
                    } else if ("RunThreshold".equals(k)) {
                        runThreshold = clampSetting(Double.parseDouble(v), 0.50, 3.5);
                    } else if ("SprintThreshold".equals(k)) {
                        sprintThreshold = clampSetting(Double.parseDouble(v), 1.00, 4.5);
                    }
                }
            }
            lastSettingsSig = sig;
            if (wasEnabled && !enabled) {
                resetTracking();
            }
        } catch (Throwable ignored) {}
    }

    public static synchronized void resetTracking() {
        hasPrevLeft = false;
        hasPrevRight = false;
        engaged = false;
        leftVel = 0.0;
        rightVel = 0.0;
        leftRecentPeak = 0.0;
        rightRecentPeak = 0.0;
        strideVel = 0.0;
        reversalHoldTimer = 0.0;
        smoothedWalkScale = 0.65;
        swingEnergy = 0.0;
        gaitMode = "IDLE";
        running = false;
        sprinting = false;
        drivingThisTick = false;
        lastSampleNanos = 0L;
        lastTickNanos = 0L;
        savedRootActive = false;
        savedRootPlayer = null;
    }

    public static synchronized void tickXr() {
        try {
            reloadSettingsFromDisk(false);
            if (!enabled) {
                resetTracking();
                return;
            }

            long nowNanos = System.nanoTime();
            double tickDt = lastTickNanos == 0L ? 0.016 : (nowNanos - lastTickNanos) / 1_000_000_000.0;
            if (tickDt <= 0.0 || tickDt > 0.25) tickDt = 0.016;
            lastTickNanos = nowNanos;

            boolean active = false;
            try {
                active = Engine.active();
            } catch (Throwable ignored) {
                active = false;
            }

            if (active) {
                XrBackend.Frame frame = Engine.latest;
                if (frame != null && frame.head() != null && frame.head().position() != null) {
                    long fTime = frame.time();
                    // Sample at ~60Hz (16ms window) so Quest 3 OpenXR micro-jitter cannot spike velocity
                    if (fTime != lastFrameTime && (lastSampleNanos == 0L || nowNanos - lastSampleNanos >= 16_000_000L)) {
                        double dt = lastSampleNanos == 0L ? 0.016 : (nowNanos - lastSampleNanos) / 1_000_000_000.0;
                        if (dt < 0.012) dt = 0.012;
                        if (dt > 0.25) {
                            hasPrevLeft = false;
                            hasPrevRight = false;
                            dt = 0.016;
                        }

                        Math3.Vec headPos = frame.head().position();
                        double hx = headPos.x(), hy = headPos.y(), hz = headPos.z();

                        XrBackend.Hand left = frame.left();
                        if (left != null && left.tracked() && left.grip() != null && left.grip().position() != null) {
                            Math3.Vec wPos = left.grip().position();
                            double wx = wPos.x(), wy = wPos.y(), wz = wPos.z();
                            double rx = wx - hx, ry = wy - hy, rz = wz - hz;
                            if (hasPrevLeft) {
                                double wDx = wx - prevWorldLx;
                                double wDy = wy - prevWorldLy;
                                double wDz = wz - prevWorldLz;
                                double wDist = Math.sqrt(wDx * wDx + wDy * wDy + wDz * wDz);

                                double rDx = rx - prevRelLx;
                                double rDy = ry - prevRelLy;
                                double rDz = rz - prevRelLz;
                                double rDist = Math.sqrt(rDx * rDx + rDy * rDy + rDz * rDz);

                                // Require motion in BOTH world space AND head-relative space so turning your head
                                // or leaning with arms at your sides produces 0 velocity.
                                double dist = Math.min(wDist, rDist);
                                if (dist < 0.0030) dist = 0.0;
                                double v = Math.min(8.0, (dist / dt) * sensitivity);
                                double alpha = v >= leftVel ? 0.36 : 0.22;
                                leftVel = leftVel + (v - leftVel) * alpha;
                                if (leftVel < 0.03) leftVel = 0.0;
                            }
                            prevWorldLx = wx;
                            prevWorldLy = wy;
                            prevWorldLz = wz;
                            prevRelLx = rx;
                            prevRelLy = ry;
                            prevRelLz = rz;
                            hasPrevLeft = true;
                        } else {
                            hasPrevLeft = false;
                            leftVel = 0.0;
                        }

                        XrBackend.Hand right = frame.right();
                        if (right != null && right.tracked() && right.grip() != null && right.grip().position() != null) {
                            Math3.Vec wPos = right.grip().position();
                            double wx = wPos.x(), wy = wPos.y(), wz = wPos.z();
                            double rx = wx - hx, ry = wy - hy, rz = wz - hz;
                            if (hasPrevRight) {
                                double wDx = wx - prevWorldRx;
                                double wDy = wy - prevWorldRy;
                                double wDz = wz - prevWorldRz;
                                double wDist = Math.sqrt(wDx * wDx + wDy * wDy + wDz * wDz);

                                double rDx = rx - prevRelRx;
                                double rDy = ry - prevRelRy;
                                double rDz = rz - prevRelRz;
                                double rDist = Math.sqrt(rDx * rDx + rDy * rDy + rDz * rDz);

                                double dist = Math.min(wDist, rDist);
                                if (dist < 0.0030) dist = 0.0;
                                double v = Math.min(8.0, (dist / dt) * sensitivity);
                                double alpha = v >= rightVel ? 0.36 : 0.22;
                                rightVel = rightVel + (v - rightVel) * alpha;
                                if (rightVel < 0.03) rightVel = 0.0;
                            }
                            prevWorldRx = wx;
                            prevWorldRy = wy;
                            prevWorldRz = wz;
                            prevRelRx = rx;
                            prevRelRy = ry;
                            prevRelRz = rz;
                            hasPrevRight = true;
                        } else {
                            hasPrevRight = false;
                            rightVel = 0.0;
                        }

                        lastFrameTime = fTime;
                        lastSampleNanos = nowNanos;
                    } else if (lastSampleNanos > 0L && nowNanos - lastSampleNanos > 80_000_000L) {
                        double stallDecay = Math.max(0.0, 1.0 - tickDt * 6.0);
                        leftVel *= stallDecay;
                        rightVel *= stallDecay;
                    }
                }
            } else {
                hasPrevLeft = false;
                hasPrevRight = false;
                leftVel = 0.0;
                rightVel = 0.0;
                lastSampleNanos = nowNanos;
            }

            // Track recent peak of each arm over ~0.55s so alternating direction reversals never lose bilateral credit
            if (leftVel > leftRecentPeak) leftRecentPeak = leftVel;
            else leftRecentPeak = Math.max(0.0, leftRecentPeak - tickDt * 1.25);
            if (rightVel > rightRecentPeak) rightRecentPeak = rightVel;
            else rightRecentPeak = Math.max(0.0, rightRecentPeak - tickDt * 1.25);

            double minThresh = Math.max(0.25, minSwingSpeed);
            double runThresh = Math.max(minThresh + 0.35, runThreshold);
            double sprintThresh = Math.max(runThresh + 0.45, sprintThreshold);

            double rawCombined;
            double avg = (leftVel + rightVel) * 0.5;
            double peak = Math.max(leftVel, rightVel);
            double recentMinor = Math.min(leftRecentPeak, rightRecentPeak);
            if (recentMinor >= Math.max(0.25, minThresh * 0.45)) {
                rawCombined = Math.max(avg, peak * 0.90);
            } else {
                rawCombined = peak * 0.62;
            }

            // Turnaround bridge: carry walk smoothly across ~220ms swing reversals without chopping
            if (rawCombined >= minThresh * 0.78) {
                reversalHoldTimer = 0.22;
            } else {
                reversalHoldTimer = Math.max(0.0, reversalHoldTimer - tickDt);
            }

            // Blade & Sorcery style rolling momentum ramp: responsive walk start, sustained pump required for Sprint
            if (rawCombined >= strideVel) {
                double attackRate = rawCombined >= runThresh ? 4.8 : 8.5;
                strideVel = strideVel + (rawCombined - strideVel) * Math.min(1.0, tickDt * attackRate);
            } else if (reversalHoldTimer > 0.0) {
                strideVel = Math.max(0.0, strideVel - tickDt * 0.30);
            } else {
                strideVel = Math.max(0.0, strideVel - Math.max(2.0, strideVel * 6.8) * tickDt);
            }
            if (rawCombined >= minThresh || (engaged && reversalHoldTimer > 0.0)) {
                double chargeSpeed = 4.5 + Math.min(3.0, Math.max(0.0, rawCombined - minThresh) * 1.2);
                swingEnergy = Math.min(1.0, swingEnergy + tickDt * chargeSpeed);
            } else {
                double drainSpeed = Math.max(5.0, decayRate * 24.0);
                swingEnergy = Math.max(0.0, swingEnergy - tickDt * drainSpeed);
            }

            // Hysteresis gate requires ~140ms sustained swing to engage and holds through arm turnarounds
            if (!engaged && swingEnergy >= 0.60) {
                engaged = true;
            } else if (engaged && swingEnergy <= 0.18) {
                engaged = false;
            }

            if (engaged) {
                sprinting = strideVel >= sprintThresh;
                running = !sprinting && strideVel >= runThresh;
                drivingThisTick = true;
                gaitMode = sprinting ? "SPRINT" : (running ? "JOG" : "WALK");
            } else {
                running = false;
                sprinting = false;
                drivingThisTick = false;
                gaitMode = "IDLE";
            }
        } catch (Throwable ignored) {}
    }

    public static void captureRootMotion(IsoPlayer player, Vector2 vector) {
        if (player != null && vector != null) {
            savedRootPlayer = player;
            savedRootX = vector.x;
            savedRootY = vector.y;
            savedRootActive = true;
        } else {
            savedRootActive = false;
            savedRootPlayer = null;
        }
    }

    public static void restoreRootMotion(IsoPlayer player, Vector2 vector) {
        try {
            // Only restore PZ's own per-frame animation root-motion displacement when Arm-Swing is driving.
            // NEVER inject a 1.0 unit vector here (rootMotion is tiles/frame, not input throttle!).
            if (savedRootActive && player == savedRootPlayer && vector != null) {
                if (enabled && drivingThisTick && (savedRootX != 0.0f || savedRootY != 0.0f)) {
                    vector.set(savedRootX, savedRootY);
                }
            }
        } catch (Throwable ignored) {
        } finally {
            savedRootActive = false;
            savedRootPlayer = null;
        }
    }

    public static void applyToMoveVector(IsoPlayer player, Vector2 outVec, boolean fromRootHook) {
        try {
            if (fromRootHook) {
                return;
            }
            tickXr();

            if (!enabled || !Engine.active() || player == null || outVec == null) {
                if (player != null && wasDrivingLastTick) {
                    player.setSprinting(false);
                    player.setRunning(false);
                    wasDrivingLastTick = false;
                }
                return;
            }
            if (player.isDead() || player.getVehicle() != null) {
                if (wasDrivingLastTick) {
                    player.setSprinting(false);
                    player.setRunning(false);
                    wasDrivingLastTick = false;
                }
                return;
            }

            // Do not override real stick/WASD movement when allowStickOverride is enabled
            if (allowStickOverride && outVec.getLengthSquared() > 0.0025f) {
                drivingThisTick = false;
                wasDrivingLastTick = false;
                gaitMode = "STICK";
                return;
            }

            if (!engaged || !drivingThisTick) {
                if (wasDrivingLastTick) {
                    player.setSprinting(false);
                    player.setRunning(false);
                    wasDrivingLastTick = false;
                }
                return;
            }

            float fx = player.getForwardDirectionX();
            float fy = player.getForwardDirectionY();
            double mag = Math.sqrt(fx * fx + fy * fy);
            if (mag < 0.001) {
                double angle = player.getDirectionAngle();
                fx = (float) Math.cos(angle);
                fy = (float) Math.sin(angle);
            } else {
                fx = (float) (fx / mag);
                fy = (float) (fy / mag);
            }

            // Smoothly scale Walk input throttle (0.55..1.0) using envelope strideVel; lock Jog/Sprint to 1.0f
            double minThresh = Math.max(0.25, minSwingSpeed);
            double runThresh = Math.max(minThresh + 0.35, runThreshold);
            float moveScale = 1.0f;
            if (!running && !sprinting) {
                double walkSpan = Math.max(0.25, runThresh - minThresh);
                double walkFrac = Math.max(0.0, Math.min(1.0, (strideVel - minThresh) / walkSpan));
                double targetScale = 0.55 + 0.45 * walkFrac;
                smoothedWalkScale = smoothedWalkScale + (targetScale - smoothedWalkScale) * 0.22;
                moveScale = (float) smoothedWalkScale;
            } else {
                smoothedWalkScale = 1.0;
            }

            outVec.set(fx * moveScale, fy * moveScale);
            drivingThisTick = true;
            wasDrivingLastTick = true;

            if (sprinting) {
                player.setRunning(false);
                player.setSprinting(true);
            } else if (running) {
                player.setSprinting(false);
                player.setRunning(true);
            } else {
                player.setSprinting(false);
                player.setRunning(false);
            }
        } catch (Throwable ignored) {}
    }

    public static int desiredSpeedKey() {
        if (!enabled || !drivingThisTick) return -1;
        try {
            Core core = Core.getInstance();
            if (core == null) return -1;
            if (sprinting) {
                if (cachedSprintKey <= 0) cachedSprintKey = core.getKey("Sprint");
                return cachedSprintKey;
            }
            if (running) {
                if (cachedRunKey <= 0) cachedRunKey = core.getKey("Run");
                return cachedRunKey;
            }
        } catch (Throwable ignored) {
        }
        return -1;
    }
}
