package com.pzvr.armswing;

import me.zed_0xff.zombie_buddy.Exposer;

@Exposer.LuaClass(name = "ArmSwingApi")
public class ArmSwingApi {
    public static String gaitMode() {
        return ArmSwingState.gaitMode;
    }

    public static void setEnabled(boolean enabled) {
        ArmSwingState.enabled = enabled;
        if (!enabled) ArmSwingState.resetTracking();
    }

    public static void setSensitivity(double sensitivity) {
        ArmSwingState.sensitivity = Math.max(0.25, Math.min(3.0, sensitivity));
    }

    public static void setMinSwingSpeed(double minSwingSpeed) {
        ArmSwingState.minSwingSpeed = Math.max(0.25, Math.min(2.0, minSwingSpeed));
    }

    public static void setRunThreshold(double runThreshold) {
        ArmSwingState.runThreshold = Math.max(0.50, Math.min(3.5, runThreshold));
    }

    public static void setSprintThreshold(double sprintThreshold) {
        ArmSwingState.sprintThreshold = Math.max(1.00, Math.min(4.5, sprintThreshold));
    }

    public static void reloadSettings() {
        ArmSwingState.reloadSettingsFromDisk(true);
    }

    public static void configure(
        boolean enabled,
        double sensitivity,
        double runThreshold,
        double sprintThreshold,
        double smoothing,
        double decayRate,
        String source,
        boolean allowStick,
        double minSwingSpeed
    ) {
        boolean wasEnabled = ArmSwingState.enabled;
        ArmSwingState.enabled = enabled;
        ArmSwingState.sensitivity = sensitivity;
        ArmSwingState.runThreshold = runThreshold;
        ArmSwingState.sprintThreshold = sprintThreshold;
        ArmSwingState.smoothing = smoothing;
        ArmSwingState.decayRate = decayRate;
        ArmSwingState.allowStickOverride = allowStick;
        ArmSwingState.minSwingSpeed = minSwingSpeed;
        if (!enabled && wasEnabled) {
            ArmSwingState.resetTracking();
        }
    }
}
