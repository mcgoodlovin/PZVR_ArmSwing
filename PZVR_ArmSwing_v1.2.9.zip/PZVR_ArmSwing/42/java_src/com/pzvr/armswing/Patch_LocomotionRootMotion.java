package com.pzvr.armswing;

import me.zed_0xff.zombie_buddy.Patch;
import zombie.characters.IsoPlayer;
import zombie.iso.Vector2;

@Patch(className = "local.pzvr.Locomotion", methodName = "rootMotion")
public class Patch_LocomotionRootMotion {
    @Patch.OnEnter
    public static void enter(@Patch.Argument(0) IsoPlayer player, @Patch.Argument(1) Vector2 vector) {
        ArmSwingState.captureRootMotion(player, vector);
    }

    @Patch.OnExit
    public static void exit(@Patch.Argument(0) IsoPlayer player, @Patch.Argument(1) Vector2 vector) {
        ArmSwingState.restoreRootMotion(player, vector);
    }
}
